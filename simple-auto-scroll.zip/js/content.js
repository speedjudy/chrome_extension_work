window.onscroll = function() {
  var d = document.documentElement;
  console.log('At the top');
  var offset = d.scrollTop + window.innerHeight;
  var height = d.offsetHeight;
  if (offset >= height) {
    chrome.runtime.sendMessage({ bottom: true })
  }
};
chrome